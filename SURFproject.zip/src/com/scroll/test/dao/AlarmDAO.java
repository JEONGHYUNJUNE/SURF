package com.scroll.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.scroll.test.dto.AlarmDto;
import com.scroll.test.dto.FriendDto;
import com.scroll.test.dto.TestDto;

import util.DBManager;

public class AlarmDAO {
   public AlarmDAO() {
   }

   private static AlarmDAO instance = new AlarmDAO();

   public static AlarmDAO getInstance() {
      return instance;
   }
   public ArrayList<AlarmDto> alarmlist(String userid) {
      AlarmDto adto = null;
      String sql =  "select userid,username,bnum,readattr,attr,adate,anum,to_char(adate,'HH24:MI') from alarm_"+userid+" order by adate desc";
      ArrayList<AlarmDto> list = new ArrayList<AlarmDto>();
      Connection conn = null;
      Statement stmt = null;
      ResultSet rs = null;
      try {
         conn = DBManager.getConnection();
         stmt = conn.createStatement();
         rs = stmt.executeQuery(sql);
         while (rs.next()) {
            adto = new AlarmDto();
            adto.setUserid(rs.getString("userid"));
            adto.setUsername(rs.getString("username"));
            adto.setBnum(rs.getInt("bnum"));
            adto.setReadattr(rs.getInt("readattr"));
            adto.setAttr(rs.getInt("attr"));
            adto.setAdate(rs.getDate("adate"));
            adto.setAdatemin(rs.getString("to_char(adate,'HH24:MI')"));
            adto.setAnum(rs.getInt("anum"));
            list.add(adto);
         }
      } catch (SQLException e) {
         e.printStackTrace();
      } finally {
         DBManager.close(conn, stmt, rs);
      }
      return list;
   }
   public void alarmadd(String userid,String userid1,String username,int bnum,int attr) { //�۾��� �׽�Ʈ
       String sql = "insert into alarm_"+userid+"(userid,username,bnum,attr,anum) values('"+userid1+"','"+username+"','"+bnum+"','"+attr+"',alarm_"+userid+"_seq.nextVal)";
       Connection conn = null;
       Statement stmt = null;
       try {
          conn = DBManager.getConnection();
          stmt = conn.createStatement();
          stmt.executeQuery(sql);
       } catch (Exception e) {
          e.printStackTrace();
       } finally {
          try {
             if (stmt != null)
                stmt.close();
             if (conn != null)
                conn.close();
          } catch (Exception e) {
             e.printStackTrace();
          }
       }
    }
   public void attrchange(int anum,String userid) { //�۾��� �׽�Ʈ
       String sql = "update alarm_"+userid+" set readattr = 1 where anum = '"+anum+"'";
       Connection conn = null;
       Statement stmt = null;
       try {
          conn = DBManager.getConnection();
          stmt = conn.createStatement();
          stmt.executeQuery(sql);
       } catch (Exception e) {
          e.printStackTrace();
       } finally {
          try {
             if (stmt != null)
                stmt.close();
             if (conn != null)
                conn.close();
          } catch (Exception e) {
             e.printStackTrace();
          }
       }
    }
}