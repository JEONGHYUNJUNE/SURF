package com.scroll.test.model;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.scroll.test.dto.AlarmDto;
import com.scroll.test.dto.MemberVO;
import com.scroll.test.dto.TestDto;
import com.scroll.test.dao.AlarmDAO;
import com.scroll.test.dao.TestDao;



@WebServlet("/alarmajax.do")
public class alarmajax extends HttpServlet {
   private static final long serialVersionUID = 1L;
  
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");
      response.setContentType("text/html;charset=UTF-8");
      String userid = request.getParameter("userid");
     response.getWriter().write(getJSON(userid));
   }
   public String getJSON(String userid) {
      String userid1 = userid;
      AlarmDAO aDao = new AlarmDAO();
      StringBuffer result = new StringBuffer("");
      result.append("{\"result\":[");
      ArrayList<AlarmDto> dtos = aDao.alarmlist(userid1);
      for(int i = 0;i<dtos.size();i++) {
         result.append("[\"" + dtos.get(i).getAdatemin()+"\",");
         result.append("\""+dtos.get(i).getAdate()+"\",");
         result.append("\""+dtos.get(i).getAnum()+"\",");
         result.append("\""+dtos.get(i).getAttr()+"\",");
         result.append("\""+dtos.get(i).getBnum()+"\",");
         result.append("\""+dtos.get(i).getReadattr()+"\",");
         result.append("\""+dtos.get(i).getUserid()+"\",");
         result.append("\""+dtos.get(i).getUsername()+"\"],");
      }
      result.append("]}");
      return result.toString();
   }
}