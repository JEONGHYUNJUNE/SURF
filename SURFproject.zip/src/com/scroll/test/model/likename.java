package com.scroll.test.model;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scroll.test.dao.MemberDAO;
import com.scroll.test.dao.TestDao;
import com.scroll.test.dto.MemberVO;
import com.scroll.test.dto.TestDto;

/**
 * Servlet implementation class fsearch
 */
@WebServlet("/likelist.do")
public class likename extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public likename() {
        super();
        // TODO Auto-generated constructor stub
    }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
      request.setCharacterEncoding("UTF-8");
      response.setContentType("text/html;charset=UTF-8");
      int tnum = Integer.parseInt(request.getParameter("tnum"));
      response.getWriter().write(getJSON(tnum));
   }
   
   public String getJSON(int tnum) {
      StringBuffer result = new StringBuffer("");
      result.append("{\"result\":[");
      TestDao dao = new TestDao(); 
      MemberDAO mdao = new MemberDAO();
      MemberVO mdto = new MemberVO();
      ArrayList<TestDto> userlist = dao.likeid(tnum);
      ArrayList<MemberVO> userlist2 = new ArrayList<MemberVO>();
      
      
      for(int i = 0; i<userlist.size(); i++) {
    	 mdto.setProfilepic(mdao.getPicture(userlist.get(i).getUserid()));
    	 mdto.setUsername(mdao.getuserName(userlist.get(i).getUserid()));
    	 userlist2.add(mdto);
         result.append("[\"" + userlist2.get(i).getProfilepic()+"\",");
         result.append("\""+userlist2.get(i).getUsername()+"\"],");
      }
      result.append("]}");
      return result.toString();
   }

}