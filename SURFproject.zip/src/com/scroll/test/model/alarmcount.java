package com.scroll.test.model;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scroll.test.dao.AlarmDAO;
import com.scroll.test.dao.MemberDAO;
import com.scroll.test.dao.TestDao;

/**
 * Servlet implementation class idcheck
 */
@WebServlet("/alarmcount.do")
public class alarmcount extends HttpServlet {
   private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public alarmcount() {
        super();
        // TODO Auto-generated constructor stub
    }

   /**
    * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
     AlarmDAO adao = new AlarmDAO();
      String userid = request.getParameter("userid");
      response.getWriter().write(adao.notread(userid));
   }

}