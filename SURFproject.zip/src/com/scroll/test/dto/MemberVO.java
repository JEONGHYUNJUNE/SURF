package com.scroll.test.dto;

public class MemberVO {
	private String userid;
	private String userpwd ;
	private String username ;
	private String email ;
	private String phonenum; 
	private String surfaddress ;
	private String profilepic ;
	private String profilebg ;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getSurfaddress() {
		return surfaddress;
	}
	public void setSurfaddress(String surfaddress) {
		this.surfaddress = surfaddress;
	}
	public String getProfilepic() {
		return profilepic;
	}
	public void setProfilepic(String profilepic) {
		this.profilepic = profilepic;
	}
	public String getProfilebg() {
		return profilebg;
	}
	public void setProfilebg(String profilebg) {
		this.profilebg = profilebg;
	}
	
}
