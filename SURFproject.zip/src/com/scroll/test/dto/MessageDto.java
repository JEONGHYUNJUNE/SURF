package com.scroll.test.dto;

public class MessageDto {
   private String writeid;
   private String recieveid;
   private int mnum;
   private String mcontent;
   private String readattr;
   private String mdate1;
   private String mdate2;
   private String writename;
   private String recievename;
public String getWriteid() {
   return writeid;
}
public void setWriteid(String writeid) {
   this.writeid = writeid;
}
public String getRecieveid() {
   return recieveid;
}
public void setRecieveid(String recieveid) {
   this.recieveid = recieveid;
}
public int getMnum() {
   return mnum;
}
public void setMnum(int mnum) {
   this.mnum = mnum;
}
public String getMcontent() {
   return mcontent;
}
public void setMcontent(String mcontent) {
   this.mcontent = mcontent;
}
public String getReadattr() {
   return readattr;
}
public void setReadattr(String readattr) {
   this.readattr = readattr;
}
public String getMdate1() {
   return mdate1;
}
public void setMdate1(String mdate1) {
   this.mdate1 = mdate1;
}
public String getMdate2() {
   return mdate2;
}
public void setMdate2(String mdate2) {
   this.mdate2 = mdate2;
}
public String getWritename() {
   return writename;
}
public void setWritename(String writename) {
   this.writename = writename;
}
public String getRecievename() {
   return recievename;
}
public void setRecievename(String recievename) {
   this.recievename = recievename;
}
   
   
}