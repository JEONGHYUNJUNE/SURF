package com.scroll.test.dto;

import java.util.Date;

public class AlarmDto {
   private String userid;
   private String username;
   private int bnum;
   private int readattr;
   private int attr;
   private Date adate;
   private int anum;
   private String adatemin;
   private int count;
   public String getUserid() {
      return userid;
   }
   public void setUserid(String userid) {
      this.userid = userid;
   }
   public int getBnum() {
      return bnum;
   }
   public void setBnum(int bnum) {
      this.bnum = bnum;
   }
   public int getReadattr() {
      return readattr;
   }
   public void setReadattr(int readattr) {
      this.readattr = readattr;
   }
   public int getAttr() {
      return attr;
   }
   public void setAttr(int attr) {
      this.attr = attr;
   }
   public Date getAdate() {
      return adate;
   }
   public void setAdate(Date adate) {
      this.adate = adate;
   }
   public String getUsername() {
      return username;
   }
   public void setUsername(String username) {
      this.username = username;
   }
   public int getAnum() {
      return anum;
   }
   public void setAnum(int anum) {
      this.anum = anum;
   }
   public String getAdatemin() {
      return adatemin;
   }
   public void setAdatemin(String adatemin) {
      this.adatemin = adatemin;
   }
public int getCount() {
   return count;
}
public void setCount(int count) {
   this.count = count;
}
   
   
}